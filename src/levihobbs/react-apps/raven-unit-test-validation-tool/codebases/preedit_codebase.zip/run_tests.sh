#!/bin/bash
# Run unit tests in the container
npm test -- --run --coverage --passWithNoTests 