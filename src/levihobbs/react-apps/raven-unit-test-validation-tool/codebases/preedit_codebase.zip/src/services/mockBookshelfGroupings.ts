import type { BookshelfGrouping } from '../types/BookReview';

// Real bookshelf groupings from database
export const mockBookshelfGroupings: BookshelfGrouping[] = [
  {
    id: 7,
    name: "History",
    displayName: undefined,
    bookshelves: [
      { id: 202, name: "topical-history", displayName: "topical-history" },
      { id: 214, name: "ancient-history", displayName: "ancient-history" },
      { id: 214, name: "renaissance-history", displayName: "renaissance-history" },
      { id: 227, name: "modern-history", displayName: "modern-history" }
    ]
  },
  {
    id: 8,
    name: "Science Fiction",
    displayName: undefined,
    bookshelves: [
      { id: 189, name: "sf-classics", displayName: "sf-classics" },
      { id: 201, name: "space-opera", displayName: "space-opera" },
      { id: 203, name: "epic-sf", displayName: "epic-sf" },
      { id: 204, name: "science-fiction-comps", displayName: "science-fiction-comps" },
      { id: 205, name: "cyberpunk", displayName: "cyberpunk" },
      { id: 206, name: "2024-science-fiction", displayName: "2024-science-fiction" }
    ]
  },
  {
    id: 9,
    name: "Fantasy",
    displayName: undefined,
    bookshelves: [
      { id: 207, name: "high-fantasy", displayName: "high-fantasy" },
      { id: 208, name: "modern-fantasy", displayName: "modern-fantasy" },
      { id: 209, name: "modern-fairy-tales", displayName: "modern-fairy-tales" },
      { id: 210, name: "folks-and-myths", displayName: "folks-and-myths" }
    ]
  },
  {
    id: 10,
    name: "Ancient Classics",
    displayName: undefined,
    bookshelves: [
      { id: 211, name: "ancient-greek", displayName: "ancient-greek" },
      { id: 214, name: "ancient-history", displayName: "ancient-history" },
      { id: 212, name: "ancient-classics", displayName: "ancient-classics" },
      { id: 213, name: "ancient-roman", displayName: "ancient-roman" }
    ]
  },
  {
    id: 11,
    name: "Classics",
    displayName: undefined,
    bookshelves: [
      { id: 211, name: "ancient-greek", displayName: "ancient-greek" },
      { id: 213, name: "ancient-roman", displayName: "ancient-roman" },
      { id: 215, name: "renaissance-classics", displayName: "renaissance-classics" },
      { id: 216, name: "modern-classics", displayName: "modern-classics" }
    ]
  }
]; 